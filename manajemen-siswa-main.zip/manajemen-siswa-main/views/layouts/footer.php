<footer class="footer">
    <p class="footer-title">SMK MIHTAHUL KHAIR</P>
    <P class="footer-text">
        &copy; <?= date('Y') ?> Manajemen Siswa. Semua hak dilindungi.
    </p>
</footer>
</body>
</html>