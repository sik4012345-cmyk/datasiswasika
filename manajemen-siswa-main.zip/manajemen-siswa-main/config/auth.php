<?php
if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

$halamanBebas = ['login.php', 'logout.php', 'buat_admin.php'];
$halamanSaatIni = basename($_SERVER['PHP_SELF']); 

if (!in_array($halamanSaatIni, $halamanBebas) && empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
