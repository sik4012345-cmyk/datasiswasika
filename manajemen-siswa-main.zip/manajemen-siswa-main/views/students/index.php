<?php require 'views/layouts/header.php'; ?> 
 
<h1>SMK MIFTAHUL KHAIR</h1>
<h1>Daftar Siswa</h1> 
 
<?php if (!empty($success)): ?>
    <div style="background:#d4edda; color:#155724; border:1px solid #c3e6cb; padding:10px; margin-bottom:15px;"> 
        <?=htmlspecialchars($success) ?>
    </div>
<?php endif;?>

<a href="create.php"> 
    + Tambah Siswa 
</a> 
 
<table border="1" cellpadding="10"> 
 
    <thead> 
        <tr> 
            <th>No</th> 
            <th>NIS</th> 
            <th>Nama</th> 
            <th>Jenis Kelamin</th> 
            <th>Kelas</th>
            <th>tempat lahir</th>
            <th>tanggal lahir</th> 
            <th>Jurusan</th> 
            <th>Aksi</th> 
        </tr> 
    </thead>
     <tbody> 
 
        <?php foreach ($students as $index => $student): ?> 
 
            <tr> 
                <td><?= $index + 1 ?></td> 
                <td><?= $student['nis'] ?></td> 
                <td><?= $student['name'] ?></td> 
                <td><?= $student['gender'] ?></td> 
                <td><?= $student['class_name'] ?></td> 
                <td><?= $student['birth_place'] ?></td> 
                <td><?= $student['birth_date'] ?></td>
                <td><?= $student['major'] ?></td> 
                <td> 
                    <a href="student.php?id=<?= $student['id'] ?>"> 
                        Detail 
                    </a> 
                    <a href="edit.php?id=<?= $student['id'] ?>"> 
                        Edit 
                    </a> 
                    <a href="delete.php?id=<?= $student['id'] ?>" onclic
k="return confirm('Apakah Anda yakin ingin menghapus siswa ini?')"> 
                        Hapus 
                    </a> 
                </td> 
            </tr> 
 
        <?php endforeach; ?> 
 
    </tbody> 
 
</table> 
 
<?php require 'views/layouts/footer.php'; ?>