<?php 
require __DIR__ . '/config/database.php'; 

if (!empty($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch();

if ($user && password_verify($password, $user['password'])) {
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];

    header('Location: index.php');
    exit;
}
  $error = 'username atau password salah.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Manajemen Siswa</title>
    <link rel="stylesheet" href="style.css">
    <style>
           
        * {box-sizing: border-box; } 
        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background:linear-gradient(135deg, #1e3a8a, #2563ab);
            font-family: "segoe UI", Arial, sans-serif;
        }

        .login-card {
            width: 100%;
            max-width: 380px;
            background: #ffffff;
            padding: 32px;
            border-radius: 14px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.25);
        }

        .login-card h1 {
            margin: 0;
            text-align: center;
            font-size: 20px;
            color: #0d6ad3;
        }

        .login-card .sub {
            text-align: center;
            margin: 4px 0 24px;
            font-size: 13px;
            color: #17bb25;
        }
        
        .login-card label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 6px;
        }

        .login-card input {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 16px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
        }

        .login-card input:focus {
            outline: none;
            border-color: #44a5dd;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.2);
        }
        .login-card button {
            width: 100%;
            padding: 11px;
            border: none;
            border-radius: 8px;
            background: #236aee;
            color: #ffffff;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
        }

        .login-card button:hover {
            background: #1e3a8a;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 16px;
            font-size: 13px;
        }
       </style>
       
</head>
<body>
<div class="login-card">
    <h1>SMK MIFTAHUL KHAIR</h1>
    <p class="sub">login Manajemen Siswa</p>
    <?php if ($error): ?>
        <div class ="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method ="POST" action="login.php">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" required autofocus>
        <label for="password">password</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">Login</button>
    </form>
</div>
</body>
</html>